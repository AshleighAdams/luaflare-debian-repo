local c = require "systemd.id128.core"

c.randomise = c.randomize

return c
