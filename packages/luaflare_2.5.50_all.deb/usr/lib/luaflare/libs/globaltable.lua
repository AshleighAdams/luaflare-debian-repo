local globaltable = {}

local tablemeta = {}

function tablemeta:update() -- pull updates since last update time
	local lastupdate = self._private.updatetime
end

function globaltable:ensure(name, persistant) expects("string", "boolean")
	
end

return globaltable
