return {
	_VERSION     = "LuaFlare 2.5.50",
	config_path  = "/etc/luaflare",
	lib_path     = "/usr/lib/luaflare",
	--[[hook         = require("luaflare.hook"),
	hosts        = require("luaflare.hosts"),
	httpstatus   = require("luaflare.httpstatus"),
	mimetypes    = require("luaflare.mimetypes"),
	scheduler    = require("luaflare.scheduler"),
	session      = require("luaflare.session"),
	tags         = require("luaflare.tags"),
	threadpool   = require("luaflare.threadpool"),
	util         = require("luaflare.util"),
	websocket    = require("luaflare.websocket"),]]
}
