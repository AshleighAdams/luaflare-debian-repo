warn("coroutine threading model not yet implimented; falling back to none!")

return require("luaflare.main.none")
